import 'package:flutter/material.dart'; 
class AppTheme { 
static const Color primaryPurple = Color(0xFF8A00D4); 
static const Color lightPurple = Color(0xFFB06BF2); 
static const Color gradientTop = Color(0xFFB06BF2); 
static const Color gradientBottom = Color(0xFF6A00B0); 
static ThemeData theme = ThemeData( 
primaryColor: primaryPurple, 
scaffoldBackgroundColor: Colors.white, 
appBarTheme: const AppBarTheme( 
backgroundColor: primaryPurple, 
      foregroundColor: Colors.white, 
      elevation: 0, 
    ), 
    elevatedButtonTheme: ElevatedButtonThemeData( 
      style: ElevatedButton.styleFrom( 
        backgroundColor: primaryPurple, 
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), 
        padding: const EdgeInsets.symmetric(vertical: 16), 
      ), 
    ), 
  ); 
 
  static BoxDecoration gradientBackground() => const BoxDecoration( 
        gradient: LinearGradient( 
          begin: Alignment.topCenter, 
          end: Alignment.bottomCenter, 
          colors: [gradientTop, gradientBottom], 
        ), 
      ); 
} 

