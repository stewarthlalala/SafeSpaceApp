import 'package:flutter/material.dart';
import 'package:safespace_safety_app/screens/mental_health_screen.dart';
import 'screens/home_screen.dart';
import 'screens/child_mode_screen.dart';
import 'screens/journal_screen.dart';
import 'screens/learning_hub_screen.dart';
import 'screens/panic_screen.dart';
import 'screens/report_screen.dart';
import 'screens/reports_list_screen.dart';
import 'screens/safe_spaces_screen.dart';

void main() {
  runApp(const SafeSpaceApp());
}

class SafeSpaceApp extends StatelessWidget {
  const SafeSpaceApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SafeSpace App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const MainTabs(),
    );
  }
}

class MainTabs extends StatefulWidget {
  const MainTabs({super.key});

  @override
  _MainTabsState createState() => _MainTabsState();
}

class _MainTabsState extends State<MainTabs> {
  int _currentIndex = 0;

  final List<Widget> _screens = [
    HomeScreen(),
    const ChildModeScreen(),
    const JournalScreen(),
    const LearningHubScreen(),
    PanicScreen(),
    ReportScreen(),
    ReportsListScreen(),
    const SafeSpacesScreen(), // <- make sure class name matches
    MentalHealthScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        type: BottomNavigationBarType.fixed,
        onTap: (index) => setState(() => _currentIndex = index),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.child_care), label: 'Child'),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: 'Journal'),
          BottomNavigationBarItem(icon: Icon(Icons.school), label: 'Learning'),
          BottomNavigationBarItem(icon: Icon(Icons.warning), label: 'Panic'),
          BottomNavigationBarItem(icon: Icon(Icons.report), label: 'Report'),
          BottomNavigationBarItem(
            icon: Icon(Icons.list),
            label: 'Reports List',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.security),
            label: 'SafeSpace',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.health_and_safety),
            label: "Mental Health",
          ),
        ],
      ),
    );
  }
}
