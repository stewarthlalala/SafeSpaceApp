import 'package:flutter/material.dart';
import 'package:safespace_safety_app/theme/app_theme.dart';
import 'package:url_launcher/url_launcher.dart';

class MentalHealthScreen extends StatelessWidget {
  const MentalHealthScreen({super.key});

  Future<void> _call(String number) async {
    final uri = Uri.parse('tel:$number');
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mental Health Support')),
      body: Container(
        decoration: AppTheme.gradientBackground(),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text(
              'You are not alone 💜',
              style: TextStyle(
                  color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            const Text(
              'If you are feeling anxious, sad, or overwhelmed, these resources can help.',
              style: TextStyle(color: Colors.white70),
            ),
            const SizedBox(height: 16),
            _supportCard('Lifeline South Africa', '0861 322 322'),
            _supportCard('Sadag Mental Health Helpline', '0800 456 789'),
            _supportCard('GBV Command Centre', '0800 428 428'),
            const SizedBox(height: 16),
            const Text(
              'Self-Care Tips 🧘‍♀',
              style: TextStyle(
                  color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            _tip('Take a walk and breathe deeply.'),
            _tip('Write in your journal daily.'),
            _tip('Talk to someone you trust about your feelings.'),
            _tip('Practice gratitude — name 3 good things today.'),
          ],
        ),
      ),
    );
  }

  Widget _supportCard(String name, String number) {
    return Card(
      color: Colors.white.withOpacity(0.9),
      margin: const EdgeInsets.only(bottom: 10),
      child: ListTile(
        leading: const Icon(Icons.local_phone, color: AppTheme.primaryPurple),
        title: Text(name),
        subtitle: Text(number),
        onTap: () => _call(number),
      ),
    );
  }

  Widget _tip(String tip) {
    return Card(
      color: Colors.white.withOpacity(0.9),
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: const Icon(Icons.favorite, color: AppTheme.primaryPurple),
        title: Text(tip),
      ),
    );
  }
}
