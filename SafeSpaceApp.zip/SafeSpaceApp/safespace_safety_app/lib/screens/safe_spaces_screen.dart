import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:safespace_safety_app/theme/app_theme.dart';

class SafeSpacesScreen extends StatelessWidget {
  const SafeSpacesScreen({super.key});

  Future<void> _callNumber(String number) async {
    final Uri uri = Uri.parse('tel:$number');
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    }
  }

  Future<void> _openDirections(String address) async {
    final Uri uri = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=${Uri.encodeComponent(address)}',
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _goToHospital() async {
    final Uri uri = Uri.parse(
      'https://www.google.com/maps/search/?api=1&query=hospital+near+me',
    );
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Safe Spaces'),
        backgroundColor: AppTheme.primaryPurple,
        elevation: 0,
      ),
      body: Container(
        decoration: AppTheme.gradientBackground(),
        child: Column(
          children: [
            const SizedBox(height: 16),

            // 🔹 Hotline quick-access row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _HotlineButton(
                    icon: Icons.local_police,
                    label: 'Police',
                    number: '10111',
                  ),
                  _HotlineButton(
                    icon: Icons.local_hospital,
                    label: 'Ambulance',
                    number: '10177',
                  ),
                  _HotlineButton(
                    icon: Icons.favorite,
                    label: 'GBV Helpline',
                    number: '0800428428',
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // 🏠 Safe space list
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  SafeSpaceCard(
                    name: 'Thuthuzela Care Centre',
                    address: '123 Main Street, Johannesburg',
                    contact: '+27 80 000 0000',
                    onCall: () => _callNumber('+27800000000'),
                    onDirections: () =>
                        _openDirections('123 Main Street, Johannesburg'),
                  ),
                  SafeSpaceCard(
                    name: 'Women’s Shelter SA',
                    address: '45 Freedom Rd, Cape Town',
                    contact: '+27 21 555 1234',
                    onCall: () => _callNumber('+27215551234'),
                    onDirections: () =>
                        _openDirections('45 Freedom Rd, Cape Town'),
                  ),
                  SafeSpaceCard(
                    name: 'Community Safe Hub',
                    address: '19 Unity St, Durban',
                    contact: '+27 31 444 2222',
                    onCall: () => _callNumber('+27314442222'),
                    onDirections: () => _openDirections('19 Unity St, Durban'),
                  ),
                ],
              ),
            ),

            // 🚨 ASAP Button (emergency)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.pinkAccent,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(
                    horizontal: 40,
                    vertical: 16,
                  ),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                  shadowColor: Colors.pinkAccent.withOpacity(0.5),
                  elevation: 10,
                ),
                icon: const Icon(Icons.emergency, size: 28),
                label: const Text(
                  'ASAP – Go to Nearest Hospital',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                onPressed: _goToHospital,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// 🔸 Hotline Button Widget
class _HotlineButton extends StatelessWidget {
  final IconData icon;
  final String label;
  final String number;
  const _HotlineButton({
    required this.icon,
    required this.label,
    required this.number,
  });

  Future<void> _callHotline() async {
    final Uri uri = Uri.parse('tel:$number');
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _callHotline,
      child: Column(
        children: [
          CircleAvatar(
            radius: 28,
            backgroundColor: Colors.white.withOpacity(0.9),
            child: Icon(icon, color: AppTheme.primaryPurple, size: 30),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}

// 🏠 SafeSpace Card Widget
class SafeSpaceCard extends StatelessWidget {
  final String name, address, contact;
  final VoidCallback onCall, onDirections;

  const SafeSpaceCard({
    super.key,
    required this.name,
    required this.address,
    required this.contact,
    required this.onCall,
    required this.onDirections,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white.withOpacity(0.9),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              name,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
            ),
            const SizedBox(height: 4),
            Text(address, style: const TextStyle(fontSize: 14)),
            const SizedBox(height: 6),
            Text(
              '📞 $contact',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
            const SizedBox(height: 10),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                ElevatedButton.icon(
                  icon: const Icon(Icons.call, size: 20),
                  label: const Text('Call'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.primaryPurple,
                    foregroundColor: Colors.white,
                  ),
                  onPressed: onCall,
                ),
                ElevatedButton.icon(
                  icon: const Icon(Icons.directions, size: 20),
                  label: const Text('Directions'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.pinkAccent,
                    foregroundColor: Colors.white,
                  ),
                  onPressed: onDirections,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
