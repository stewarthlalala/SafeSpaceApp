import 'dart:async';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:geolocator/geolocator.dart';

class PanicScreen extends StatefulWidget {
  @override
  _PanicScreenState createState() => _PanicScreenState();
}

class _PanicScreenState extends State<PanicScreen>
    with SingleTickerProviderStateMixin {
  String _hotline = '0800123456';
  bool _sending = false;
  int _tapCount = 0;
  Timer? _tapTimer;
  late AnimationController _controller;
  late Animation<double> _pulseAnimation;

  @override
  void initState() {
    super.initState();
    _controller =
        AnimationController(vsync: this, duration: const Duration(seconds: 2))
          ..repeat(reverse: true);
    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.2).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    _tapTimer?.cancel();
    super.dispose();
  }

  Future<void> _callHotline() async {
    final uri = Uri.parse('tel:$_hotline');
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  Future<void> _sendSmsWithLocation() async {
    setState(() => _sending = true);
    try {
      Position pos = await Geolocator.getCurrentPosition();
      final msg =
          '🚨 SOS! I need help. My location: https://maps.google.com/?q=${pos.latitude},${pos.longitude}';
      final uri = Uri.parse('sms:$_hotline?body=${Uri.encodeComponent(msg)}');
      if (await canLaunchUrl(uri)) await launchUrl(uri);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ Silent SOS sent successfully!'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('❌ Failed to send location.'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
    setState(() => _sending = false);
  }

  void _registerTap() {
    _tapCount++;
    _tapTimer?.cancel();
    _tapTimer = Timer(const Duration(seconds: 2), () => _tapCount = 0);
    if (_tapCount >= 4) {
      _tapCount = 0;
      _sendSmsWithLocation();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF1E1A38),
      body: Stack(
        children: [
          // 🌈 Gradient background
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF2B1055), Color(0xFF7597DE)],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),

          // 🌟 Animated SOS button
          Center(
            child: GestureDetector(
              onTap: _registerTap,
              child: ScaleTransition(
                scale: _pulseAnimation,
                child: Container(
                  width: 180,
                  height: 180,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.pinkAccent.withOpacity(0.6),
                        blurRadius: 25,
                        spreadRadius: 8,
                      ),
                    ],
                    gradient: const LinearGradient(
                      colors: [Colors.pinkAccent, Colors.redAccent],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: const Center(
                    child: Text(
                      'SOS',
                      style: TextStyle(
                        fontSize: 48,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 4,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ℹ️ Bottom info card
          Positioned(
            bottom: 40,
            left: 20,
            right: 20,
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Text(
                '💡 Tip: Tap the SOS button 4 times quickly to send a silent SOS with your location.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.white, fontSize: 16),
              ),
            ),
          ),

          // 🔘 Hotline + SMS buttons
          Positioned(
            top: 60,
            right: 20,
            left: 20,
            child: Column(
              children: [
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.2),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: const Icon(Icons.call, color: Colors.white),
                  label: Text(
                    'Call Hotline ($_hotline)',
                    style: const TextStyle(color: Colors.white),
                  ),
                  onPressed: _callHotline,
                ),
                const SizedBox(height: 10),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white.withOpacity(0.2),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                  ),
                  icon: const Icon(Icons.message, color: Colors.white),
                  label: const Text(
                    'Send SMS with Location',
                    style: TextStyle(color: Colors.white),
                  ),
                  onPressed: _sendSmsWithLocation,
                ),
              ],
            ),
          ),

          if (_sending)
            const Center(
              child: CircularProgressIndicator(color: Colors.white),
            ),
        ],
      ),
    );
  }
}

