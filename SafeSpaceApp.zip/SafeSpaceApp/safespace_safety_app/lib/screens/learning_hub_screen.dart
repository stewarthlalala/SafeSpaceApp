import 'package:flutter/material.dart';
import 'package:safespace_safety_app/theme/app_theme.dart';
import 'package:url_launcher/url_launcher.dart';

class LearningHubScreen extends StatelessWidget {
  const LearningHubScreen({super.key});

  // 📚 Updated list of resources grouped by audience
  final List<Map<String, String>> _resources = const [
    // --- Everyone ---
    {
      'category': 'For Everyone',
      'title': 'Understanding GBV',
      'link': 'https://www.unwomen.org/en/what-we-do/ending-violence-against-women',
    },
    {
      'category': 'For Everyone',
      'title': 'Know Your Rights (South Africa)',
      'link': 'https://www.justice.gov.za/vg/gbv.html',
    },
    {
      'category': 'For Everyone',
      'title': 'Support Networks and Helplines',
      'link': 'https://gbv.org.za/resources/',
    },
    // --- Students ---
    {
      'category': 'For Students',
      'title': 'Campus Safety Tips',
      'link': 'https://safety.duke.edu/personal-safety/campus-safety-tips',
    },
    {
      'category': 'For Students',
      'title': 'University Reporting Guidelines',
      'link': 'https://www.justice.gov.za/vg/',
    },
    // --- Children ---
    {
      'category': 'For Children',
      'title': 'Childline South Africa',
      'link': 'https://childlinesa.org.za/',
    },
    {
      'category': 'For Children',
      'title': 'Learn About Safe Touch & Unsafe Touch',
      'link': 'https://www.unicef.org/child-protection',
    },
    // --- Videos ---
    {
      'category': 'Awareness Videos',
      'title': 'Gender-Based Violence Awareness Video',
      'link': 'https://www.youtube.com/watch?v=aBLsWpymxsg',
    },
    {
      'category': 'Awareness Videos',
      'title': 'Surviving Gender-Based Violence',
      'link': 'https://www.youtube.com/watch?v=q_ryLm7ts9E',
    },
  ];

  Future<void> _openLink(String url) async {
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  IconData _getIcon(String url) {
    if (url.contains('youtube')) return Icons.play_circle_fill;
    if (url.contains('child')) return Icons.child_care;
    if (url.contains('campus') || url.contains('university')) return Icons.school;
    if (url.contains('support') || url.contains('helpline')) return Icons.favorite;
    return Icons.menu_book;
  }

  Color _getIconColor(String url) {
    if (url.contains('youtube')) return Colors.redAccent;
    if (url.contains('child')) return Colors.orangeAccent;
    if (url.contains('school')) return Colors.blueAccent;
    if (url.contains('support') || url.contains('helpline')) return Colors.pinkAccent;
    return AppTheme.primaryPurple;
  }

  @override
  Widget build(BuildContext context) {
    // group by category
    final categories = _resources.map((e) => e['category']).toSet();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Learning Hub'),
        backgroundColor: AppTheme.primaryPurple,
        elevation: 0,
      ),
      body: Container(
        decoration: AppTheme.gradientBackground(),
        child: Column(
          children: [
            // 🌸 Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: const [
                  Text(
                    'Empower Yourself 💪',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    'Knowledge is your safest space — learn, heal, and rise stronger.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white70,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),

            // ⚖️ Know Your Rights summary
            Container(
              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.15),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Know Your Rights ⚖️',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 17,
                    ),
                  ),
                  SizedBox(height: 6),
                  Text(
                    '• You have the right to report abuse anonymously.\n'
                    '• You have the right to protection and support.\n'
                    '• You have the right to access mental health care.\n'
                    '• You have the right to live without fear or violence.',
                    style: TextStyle(color: Colors.white70, height: 1.4),
                  ),
                ],
              ),
            ),

            // ☎️ Hotline Section
Padding(
  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
  child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text(
        'Emergency Hotlines ☎️',
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: Colors.white,
          fontSize: 17,
        ),
      ),
      const SizedBox(height: 8),
      Row(
        children: [
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () => _openLink('tel:0800428428'), // GBV Helpline
              icon: const Icon(Icons.call),
              label: const Text('GBV Command Centre'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.pinkAccent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: ElevatedButton.icon(
              onPressed: () => _openLink('tel:10111'), // Police Helpline
              icon: const Icon(Icons.local_police),
              label: const Text('SAPS Police'),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blueAccent,
                foregroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
            ),
          ),
        ],
      ),
    ],
  ),
),


            // 📚 Resource list
            Expanded(
              child: ListView(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                children: [
                  for (final category in categories) ...[
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Text(
                        category!,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    for (final item in _resources
                        .where((e) => e['category'] == category))
                      GestureDetector(
                        onTap: () => _openLink(item['link']!),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 250),
                          curve: Curves.easeInOut,
                          margin: const EdgeInsets.only(bottom: 16),
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: [
                                Colors.white.withOpacity(0.95),
                                AppTheme.primaryPurple.withOpacity(0.08),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                            borderRadius: BorderRadius.circular(20),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.07),
                                blurRadius: 10,
                                offset: const Offset(0, 4),
                              ),
                            ],
                          ),
                          child: ListTile(
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 18, horizontal: 20),
                            leading: CircleAvatar(
                              radius: 26,
                              backgroundColor:
                                  _getIconColor(item['link']!).withOpacity(0.15),
                              child: Icon(_getIcon(item['link']!),
                                  color: _getIconColor(item['link']!), size: 28),
                            ),
                            title: Text(
                              item['title']!,
                              style: const TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            trailing: const Icon(Icons.arrow_forward_ios,
                                size: 18, color: Colors.black54),
                          ),
                        ),
                      ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
