import 'package:flutter/material.dart';
import 'package:safespace_safety_app/screens/panic_screen.dart';
import 'package:safespace_safety_app/theme/app_theme.dart';
import 'package:video_player/video_player.dart';
import 'package:animated_text_kit/animated_text_kit.dart';


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late VideoPlayerController _controller;
  bool _isVideoReady = false;

  @override
  void initState() {
    super.initState();
    _controller = VideoPlayerController.asset('assets/videos/gbv.mp4')//adding our video
      ..initialize().then((_) {
        setState(() => _isVideoReady = true);
        _controller
          ..setLooping(true)
          ..setVolume(0)
          ..play();
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: AppTheme.gradientBackground(),
        child: SafeArea(
          child: Column(
            children: [
              // Video section
              if (_isVideoReady)
                SizedBox(
                  height: MediaQuery.of(context).size.height * 0.45,
                  width: double.infinity,
                  child: ClipRRect(
                    borderRadius: const BorderRadius.only(
                      bottomLeft: Radius.circular(40),
                      bottomRight: Radius.circular(40),
                    ),
                    child: Stack(
                      fit: StackFit.expand,
                      children: [
                        FittedBox(
                          fit: BoxFit.cover,
                          child: SizedBox(
                            width: _controller.value.size.width,
                            height: _controller.value.size.height,
                            child: VideoPlayer(_controller),
                          ),
                        ),
                        Container(
  decoration: BoxDecoration(
    gradient: LinearGradient(
      colors: [
        Colors.black.withOpacity(0.25),
        Colors.transparent,
      ],
      begin: Alignment.topCenter,
      end: Alignment.bottomCenter,
    ),
  ),
),

                      ],
                    ),
                  ),
                )
              else
                const SizedBox(
                  height: 220,
                  child: Center(child: CircularProgressIndicator(color: Colors.white)),
                ),

              const SizedBox(height: 30),

              Row(
  mainAxisAlignment: MainAxisAlignment.center,
  children: [
    Icon(Icons.shield, color: Colors.white, size: 36), // smaller icon
    const SizedBox(width: 8),
    AnimatedTextKit(
      repeatForever: true,
      animatedTexts: [
        FadeAnimatedText(
          'SafeSpace',
          duration: const Duration(seconds: 3),
          textStyle: const TextStyle(
            color: Colors.white,
            fontSize: 40,
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),
      ],
    ),
  ],
),


              const SizedBox(height: 12),
              const Padding(
  padding: EdgeInsets.symmetric(horizontal: 30),
  child: Text(
    'More than a safety app, it’s a lifeline that protects, supports, and empowers.',
    textAlign: TextAlign.center,
    style: TextStyle(
      color: Colors.white70,
      fontSize: 15,
      height: 1.5,
      shadows: [
        Shadow(
          offset: Offset(0, 1),
          blurRadius: 2,
          color: Colors.black26,
        ),
      ],
    ),
  ),
),


              const Spacer(),

              Padding(
                padding: const EdgeInsets.only(bottom: 60),
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.white,
                    foregroundColor: AppTheme.primaryPurple,
                    elevation: 8,
                    shadowColor: Colors.purple.withOpacity(0.4),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                    padding:
                        const EdgeInsets.symmetric(horizontal: 80, vertical: 14),
                  ),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => PanicScreen()),
                    );
                  },
                  child: const Text(
                    'Get Started',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

