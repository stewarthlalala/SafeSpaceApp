import 'package:flutter/material.dart';
import 'package:safespace_safety_app/theme/app_theme.dart';
import 'package:url_launcher/url_launcher.dart';

class ChildModeScreen extends StatelessWidget {
  const ChildModeScreen({super.key});

  Future<void> _call(String number) async {
    final uri = Uri.parse('tel:$number');
    if (await canLaunchUrl(uri)) await launchUrl(uri);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Child Mode', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: AppTheme.lightPurple,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFE0BBE4), Color(0xFF957DAD)], // soft pastel gradient
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Section: Helplines
            _sectionHeader('Child Helplines', icon: Icons.phone_in_talk),
            const SizedBox(height: 8),
            _helplineCard(
              'Childline South Africa (24/7)',
              '08000 55 555',
              icon: Icons.call,
              color: Colors.pinkAccent,
              onTap: () => _call('0800055555'),
            ),
            _helplineCard(
              'GBV Command Centre (SMS & WhatsApp)',
              'SMS “HELP” to 31531 or WhatsApp 083 765 1235',
              icon: Icons.message,
              color: Colors.lightBlueAccent,
            ),
            const SizedBox(height: 16),

            // Section: Education
            _sectionHeader('Learn About Safety', icon: Icons.lightbulb_outline),
            const SizedBox(height: 8),
            _educationCard(
              'What is GBV?',
              'GBV means Gender-Based Violence — it happens when someone hurts another person because of their gender or identity.',
              icon: Icons.shield,
              color: Colors.orangeAccent,
            ),
            _educationCard(
              'Know Your Safe Adults',
              'If you ever feel scared, talk to a teacher, parent, or police officer you trust.',
              icon: Icons.people,
              color: Colors.greenAccent,
            ),
            _educationCard(
              'Online Safety',
              'Never share your personal details or pictures online. Ask for help if someone makes you uncomfortable.',
              icon: Icons.computer,
              color: Colors.purpleAccent,
            ),
            _educationCard(
              'Your Body, Your Right',
              'No one has the right to touch you in a way that makes you feel bad. Always speak up and get help.',
              icon: Icons.favorite,
              color: Colors.redAccent,
            ),
          ],
        ),
      ),
    );
  }

  // Custom Section Header
  Widget _sectionHeader(String text, {required IconData icon}) {
    return Row(
      children: [
        Icon(icon, color: Colors.white, size: 28),
        const SizedBox(width: 10),
        Text(
          text,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 22,
            fontWeight: FontWeight.bold,
            letterSpacing: 0.5,
          ),
        ),
      ],
    );
  }

  // Helpline Card
  Widget _helplineCard(String title, String subtitle,
      {required IconData icon, Color? color, VoidCallback? onTap}) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 4,
      color: Colors.white.withOpacity(0.95),
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        onTap: onTap,
        leading: CircleAvatar(
          backgroundColor: color ?? AppTheme.primaryPurple,
          child: Icon(icon, color: Colors.white),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(subtitle),
      ),
    );
  }

  // Education Card
  Widget _educationCard(String title, String desc,
      {required IconData icon, Color? color}) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      elevation: 4,
      color: Colors.white.withOpacity(0.95),
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: color ?? AppTheme.lightPurple,
          child: Icon(icon, color: Colors.white),
        ),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(desc),
      ),
    );
  }
}

