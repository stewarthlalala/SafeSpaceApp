import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'reports_list_screen.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:safespace_safety_app/theme/app_theme.dart';

class ReportScreen extends StatefulWidget {
  const ReportScreen({super.key});

  @override
  _ReportScreenState createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> {
  final _formKey = GlobalKey<FormState>();
  String _title = '', _description = '', _name = '';
  bool _anonymous = true;

  Future<void> _saveReport() async {
    if (!_formKey.currentState!.validate()) return;
    _formKey.currentState!.save();

    final prefs = await SharedPreferences.getInstance();
    final list = jsonDecode(prefs.getString('reports') ?? '[]') as List;
    list.add({
      'title': _title,
      'description': _description,
      'anonymous': _anonymous,
      'name': _anonymous ? null : _name,
      'timestamp': DateTime.now().toIso8601String()
    });
    await prefs.setString('reports', jsonEncode(list));

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Your voice has been heard 💜'),
        backgroundColor: AppTheme.primaryPurple,
      ),
    );

    _formKey.currentState!.reset();
    setState(() => _anonymous = true);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Submit a Safe Report'),
        backgroundColor: AppTheme.primaryPurple,
        elevation: 0,
      ),
      body: Container(
        decoration: AppTheme.gradientBackground(),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            // Animated Title
            Center(
              child: AnimatedTextKit(
                repeatForever: false,
                animatedTexts: [
                  FadeAnimatedText(
                    'Your Voice Matters 🕊️',
                    duration: const Duration(seconds: 2),
                    textStyle: const TextStyle(
                      fontSize: 28,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            Form(
              key: _formKey,
              child: Column(
                children: [
                  _inputCard(
                    icon: Icons.title,
                    label: 'Report Title',
                    maxLines: 1,
                    onSaved: (v) => _title = v!,
                    validator: (v) =>
                        v == null || v.isEmpty ? 'Please provide a title' : null,
                  ),
                  const SizedBox(height: 12),
                  _inputCard(
                    icon: Icons.description,
                    label: 'Describe what happened',
                    maxLines: 5,
                    onSaved: (v) => _description = v!,
                    validator: (v) => v == null || v.isEmpty
                        ? 'Please provide a description'
                        : null,
                  ),
                  const SizedBox(height: 12),
                  Card(
                    color: Colors.white.withOpacity(0.9),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12)),
                    child: SwitchListTile(
                      title: const Text('Submit Anonymously'),
                      value: _anonymous,
                      onChanged: (v) => setState(() => _anonymous = v),
                      secondary: const Icon(
                        Icons.visibility_off,
                        color: AppTheme.primaryPurple,
                      ),
                    ),
                  ),
                  if (!_anonymous) ...[
                    const SizedBox(height: 12),
                    _inputCard(
                      icon: Icons.person,
                      label: 'Your Name (Optional)',
                      maxLines: 1,
                      onSaved: (v) => _name = v ?? '',
                    ),
                  ],
                  const SizedBox(height: 20),

                  // Submit Button
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      foregroundColor: AppTheme.primaryPurple,
                      elevation: 6,
                      shadowColor: Colors.purple.withOpacity(0.3),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 80, vertical: 16),
                    ),
                    onPressed: _saveReport,
                    icon: const Icon(Icons.send),
                    label: const Text(
                      'Submit Safely',
                      style:
                          TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // View Submitted Reports Button
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white.withOpacity(0.9),
                      foregroundColor: AppTheme.primaryPurple,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30)),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 30, vertical: 14),
                    ),
                    icon: const Icon(Icons.list_alt),
                    label: const Text('View Submitted Reports'),
                    onPressed: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ReportsListScreen()),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _inputCard({
    required IconData icon,
    required String label,
    int maxLines = 1,
    FormFieldSetter<String>? onSaved,
    FormFieldValidator<String>? validator,
  }) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeInOut,
      child: Card(
        color: Colors.white.withOpacity(0.9),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 2,
        shadowColor: Colors.black.withOpacity(0.05),
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: TextFormField(
            decoration: InputDecoration(
              labelText: label,
              border: InputBorder.none,
              prefixIcon: Icon(icon, color: AppTheme.primaryPurple),
            ),
            maxLines: maxLines,
            onSaved: onSaved,
            validator: validator,
          ),
        ),
      ),
    );
  }
}

