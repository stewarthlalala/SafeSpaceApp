import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:safespace_safety_app/theme/app_theme.dart';

class ReportsListScreen extends StatefulWidget {
  const ReportsListScreen({super.key});

  @override
  _ReportsListScreenState createState() => _ReportsListScreenState();
}

class _ReportsListScreenState extends State<ReportsListScreen> {
  List _reports = [];

  @override
  void initState() {
    super.initState();
    _loadReports();
  }

  Future<void> _loadReports() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() => _reports = jsonDecode(prefs.getString('reports') ?? '[]'));
  }

  @override
  Widget build(BuildContext context) {
    final reversedReports = _reports.reversed.toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('My Reports 🕊️'),
        backgroundColor: AppTheme.primaryPurple,
        elevation: 0,
      ),
      body: Container(
        decoration: AppTheme.gradientBackground(),
        child: _reports.isEmpty
            ? const Center(
                child: Padding(
                  padding: EdgeInsets.all(24.0),
                  child: Text(
                    'No reports yet.\nYour courage to speak up can make a difference 💜',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.white70, fontSize: 16),
                  ),
                ),
              )
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: reversedReports.length,
                itemBuilder: (context, i) {
                  final r = reversedReports[i];
                  final anonymous = r['anonymous'] == true;
                  final date = r['timestamp'] ?? 'Recently submitted';

                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                    margin: const EdgeInsets.only(bottom: 16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.white.withOpacity(0.95),
                          AppTheme.primaryPurple.withOpacity(0.08),
                        ],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(18),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.08),
                          blurRadius: 8,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(16),
                      leading: CircleAvatar(
                        backgroundColor:
                            anonymous ? Colors.grey[300] : AppTheme.primaryPurple.withOpacity(0.2),
                        child: Icon(
                          anonymous ? Icons.lock_outline : Icons.person_outline,
                          color: AppTheme.primaryPurple,
                        ),
                      ),
                      title: Text(
                        r['title'] ?? 'Untitled Report',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.black87,
                        ),
                      ),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 6.0),
                        child: Text(
                          '${r['description']}\n\nAnonymous: ${anonymous ? 'Yes' : 'No'}\n$date',
                          style: const TextStyle(
                            fontSize: 14,
                            height: 1.4,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}

